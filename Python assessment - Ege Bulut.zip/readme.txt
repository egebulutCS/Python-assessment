Hello,

This project involves 3 parts in its code:
1- Prime numbers within first 200 numbers
2- Checking large prime numbers by a given number list*
3- Checking if the given number is prime after checking if it is calculatable.

*For the second part as given in the codes comments section since the number list's
path has changed it needs to be redifened. If the expectation from the project is
a program calculating prime numbers with just running the program itself, then
there is also a version without the list included. The numbers will be still calculated,
the list is only included to have a faster reaction from the program.

Flow chart, pseudocode, python codes and python executables are in the folder; Prime number checker.
Number list and code belongs to it is included in Large prime number list checker folder with python executable.
Screenshots linked to both program about the operations are given in Screenshot proofs folder.
